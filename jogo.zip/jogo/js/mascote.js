//posição Player
let yPlayer = 480;
let xPlayer = 70;
let meusPontos = 0;

let colisao = false;

function verificaColisao() {
    for (let i = 0; i < imagensBirds.length; i++) {

    colisao = collideRectCircle(xBirds[i], yBirds[i], comprimentoBirds, alturaBirds, xPlayer, yPlayer, 20);
    if (colisao) {
        voltaPontos();
        if (meusPontos > 0) {
            meusPontos -= 1;
        }
        
    }
    }

    print('Colisao Acontecendo', colisao)
}

function voltaPontos() {
    yPlayer = 480
}

function mostrarPlayer() {
    image(imagemDoPlayer, xPlayer, yPlayer, 40, 40);
}

function incluirPontos() {
    
    text(meusPontos, 20,25)
    fill(color(178, 32, 25))
    textSize (21)
    
    if (yPlayer < 0) {
        yPlayer = 407;
        meusPontos ++; 
    }
}

//movimento Player
function movimentoPlayer() {
    if (keyIsDown(UP_ARROW)) {
        
        yPlayer -=5;
    }

    if (keyIsDown(DOWN_ARROW)) {

        yPlayer +=5;
        
    }

    if (keyIsDown(LEFT_ARROW)) {
        
        xPlayer -=5;
    }

    if (keyIsDown(RIGHT_ARROW)) {

        xPlayer +=5;
        
    }
}

