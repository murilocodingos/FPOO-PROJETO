
//a função setup define as config de largura e altura
function setup() {

    createCanvas(700, 600)

}

// a função draw define o que sera exibido
function draw() {

    background(imagemDoFundo);
    //image permite manipular o eixo X e Y como tambem W e H
    mostrarPlayer();
    mostrarBirds();
    movimentoBird();
    movimentoPlayer();
    incluirPontos();
    verificaColisao();
}

