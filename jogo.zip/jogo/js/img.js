//imagens
let imagemDoFundo;
let imagemDoPlayer;
let imagemDoBird1;
let imagemDoBird2;
let imagemDoBird3;

let imagensBirds;


function preload() {
    imagemDoFundo = loadImage("img/background.png");
    imagemDoPlayer = loadImage("img/king-pig.png");
    imagemDoBird1 = loadImage("img/red-1.png");
    imagemDoBird2 = loadImage("img/bomb-1.png");
    imagemDoBird3 = loadImage("img/blue-1.png");

    imagensBirds = [imagemDoBird1, imagemDoBird2, imagemDoBird3, imagemDoBird1, imagemDoBird2, imagemDoBird3];
}
