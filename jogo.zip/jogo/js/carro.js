//posição Birds
// let xBirds = 330;
// let xBirds2 = 600;
// let xBirds3 = 500;
let xBirds =[660, 660, 660, 660, 660, 660]
let yBirds =[40, 90, 170, 240, 310, 390]
let velocidadeBirds = [11, 8, 13, 10, 6, 15]

let comprimentoBirds = 30;
let alturaBirds = 30;

function mostrarBirds() {
    for (let i = 0; i < imagensBirds.length; i++) {
    
    image(imagensBirds[i], xBirds[i], yBirds[i], 45, 45);    
    }
    // image(imagemDoBird1, xBirds, 40, comprimentoBirds, alturaBirds);
    // image(imagemDoBird2, xBirds2, 95, 40, 40);
    // image(imagemDoBird3, xBirds3, 145, 40, 40);    
}

//movimento Birds
function movimentoBird() {

    for (let i = 0; i < imagensBirds.length; i++) {
        xBirds[i] -= velocidadeBirds[i];

        if (xBirds[i] < -comprimentoBirds) {
            xBirds[i] = width;
        }
        
    }

}